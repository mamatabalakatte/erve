import React, { useState } from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';

function App() {
  const [selectedTimeRange, setSelectedTimeRange] = useState('24h');
  const [selectedStation, setSelectedStation] = useState('all');
  const [viewMode, setViewMode] = useState('overview');

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar 
          selectedTimeRange={selectedTimeRange}
          setSelectedTimeRange={setSelectedTimeRange}
          selectedStation={selectedStation}
          setSelectedStation={setSelectedStation}
          viewMode={viewMode}
          setViewMode={setViewMode}
        />
        <Dashboard 
          selectedTimeRange={selectedTimeRange}
          selectedStation={selectedStation}
          viewMode={viewMode}
        />
      </div>
    </div>
  );
}

export default App;