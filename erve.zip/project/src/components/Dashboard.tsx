import React from 'react';
import DemandChart from './charts/DemandChart';
import PredictionChart from './charts/PredictionChart';
import StationMap from './charts/StationMap';
import MetricsCards from './MetricsCards';
import DemandTable from './DemandTable';
import DataImport from './DataImport';
import { datasetManager } from '../data/datasetManager';

interface DashboardProps {
  selectedTimeRange: string;
  selectedStation: string;
  viewMode: string;
}

const Dashboard: React.FC<DashboardProps> = ({ selectedTimeRange, selectedStation, viewMode }) => {
  const handleDataImported = (data: any) => {
    console.log('Data imported:', data);
    // In a real application, you would integrate this with your data management system
    alert(`Successfully imported ${Array.isArray(data) ? data.length : 'multiple'} records!`);
  };

  const renderContent = () => {
    switch (viewMode) {
      case 'overview':
        return (
          <div className="space-y-6">
            <MetricsCards timeRange={selectedTimeRange} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DemandChart timeRange={selectedTimeRange} station={selectedStation} />
              <PredictionChart timeRange={selectedTimeRange} station={selectedStation} />
            </div>
            <DemandTable timeRange={selectedTimeRange} station={selectedStation} />
          </div>
        );
      case 'predictions':
        return (
          <div className="space-y-6">
            <MetricsCards timeRange={selectedTimeRange} showPredictions={true} />
            <div className="grid grid-cols-1 gap-6">
              <PredictionChart timeRange={selectedTimeRange} station={selectedStation} detailed={true} />
            </div>
            <DemandTable timeRange={selectedTimeRange} station={selectedStation} />
          </div>
        );
      case 'locations':
        return (
          <div className="space-y-6">
            <StationMap selectedStation={selectedStation} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DemandChart timeRange={selectedTimeRange} station={selectedStation} />
              <DemandTable timeRange={selectedTimeRange} station={selectedStation} />
            </div>
          </div>
        );
      case 'settings':
        return (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Data Management</h2>
              <p className="text-gray-600 mb-6">
                Import your own EV charging demand datasets or export current data for analysis.
              </p>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <DataImport onDataImported={handleDataImported} />
                
                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Current Dataset</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Total Records:</span>
                      <span className="font-medium">{datasetManager.getHistoricalData().length.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Stations:</span>
                      <span className="font-medium">{datasetManager.getStations().length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Time Range:</span>
                      <span className="font-medium">90 days</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Models:</span>
                      <span className="font-medium">{datasetManager.getPredictionModels().length}</span>
                    </div>
                    
                    <div className="pt-4 border-t border-gray-200">
                      <button
                        onClick={() => {
                          const csvData = datasetManager.exportData('csv', selectedStation === 'all' ? undefined : selectedStation);
                          const blob = new Blob([csvData], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `ev-dataset-${new Date().toISOString().split('T')[0]}.csv`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                        }}
                        className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                      >
                        Export Current Dataset
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Model Configuration</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {datasetManager.getPredictionModels().map((model, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-900">{model.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">Type: {model.type}</p>
                    <p className="text-sm text-gray-600">Accuracy: {model.accuracy}%</p>
                    <p className="text-sm text-gray-600">
                      Last Trained: {model.lastTrained.toLocaleDateString()}
                    </p>
                    <div className="mt-2">
                      <p className="text-xs text-gray-500">Features:</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {model.features.map((feature, idx) => (
                          <span
                            key={idx}
                            className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded"
                          >
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <main className="flex-1 p-6">
      <div className="max-w-7xl mx-auto">
        {renderContent()}
      </div>
    </main>
  );
};

export default Dashboard;