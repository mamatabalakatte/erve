import React, { useState, useRef } from 'react';
import { Upload, FileText, Database, CheckCircle, AlertCircle } from 'lucide-react';

interface DataImportProps {
  onDataImported: (data: any) => void;
}

interface ImportResult {
  success: boolean;
  message: string;
  recordsProcessed?: number;
  errors?: string[];
}

const DataImport: React.FC<DataImportProps> = ({ onDataImported }) => {
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setResult(null);

    try {
      const text = await file.text();
      let data: any;
      let recordsProcessed = 0;

      if (file.name.endsWith('.csv')) {
        data = parseCSV(text);
        recordsProcessed = data.length;
      } else if (file.name.endsWith('.json')) {
        data = JSON.parse(text);
        recordsProcessed = Array.isArray(data) ? data.length : Object.keys(data).length;
      } else {
        throw new Error('Unsupported file format. Please use CSV or JSON files.');
      }

      // Validate data structure
      const validation = validateData(data);
      if (!validation.valid) {
        throw new Error(`Invalid data format: ${validation.errors.join(', ')}`);
      }

      onDataImported(data);
      setResult({
        success: true,
        message: 'Data imported successfully!',
        recordsProcessed
      });

    } catch (error) {
      setResult({
        success: false,
        message: error instanceof Error ? error.message : 'Failed to import data',
        errors: [error instanceof Error ? error.message : 'Unknown error']
      });
    } finally {
      setImporting(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const parseCSV = (text: string): any[] => {
    const lines = text.trim().split('\n');
    if (lines.length < 2) throw new Error('CSV file must have headers and at least one data row');

    const headers = lines[0].split(',').map(h => h.trim());
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      if (values.length !== headers.length) continue;

      const record: any = {};
      headers.forEach((header, index) => {
        record[header] = values[index];
      });
      data.push(record);
    }

    return data;
  };

  const validateData = (data: any): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];

    if (!Array.isArray(data)) {
      if (typeof data === 'object' && data.data && Array.isArray(data.data)) {
        data = data.data; // Handle exported JSON format
      } else {
        errors.push('Data must be an array of records');
        return { valid: false, errors };
      }
    }

    if (data.length === 0) {
      errors.push('Dataset cannot be empty');
      return { valid: false, errors };
    }

    // Check required fields
    const requiredFields = ['timestamp', 'stationId', 'actualDemand'];
    const sampleRecord = data[0];
    
    requiredFields.forEach(field => {
      if (!(field in sampleRecord)) {
        errors.push(`Missing required field: ${field}`);
      }
    });

    // Validate data types
    if (sampleRecord.timestamp && isNaN(Date.parse(sampleRecord.timestamp))) {
      errors.push('Invalid timestamp format');
    }

    if (sampleRecord.actualDemand && isNaN(Number(sampleRecord.actualDemand))) {
      errors.push('actualDemand must be a number');
    }

    return { valid: errors.length === 0, errors };
  };

  const generateSampleData = () => {
    const sampleCSV = `timestamp,stationId,actualDemand,predictedDemand,temperature,weather
2024-01-01T08:00:00Z,station-1,45,42,18.5,sunny
2024-01-01T09:00:00Z,station-1,52,48,19.2,sunny
2024-01-01T10:00:00Z,station-1,38,41,20.1,cloudy
2024-01-01T11:00:00Z,station-1,63,59,21.3,cloudy`;

    const blob = new Blob([sampleCSV], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample-ev-data.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
      <div className="text-center">
        <div className="mx-auto w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
          <Upload className="w-6 h-6 text-blue-600" />
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Import Dataset</h3>
        <p className="text-gray-600 mb-6">
          Upload your EV charging demand data in CSV or JSON format
        </p>

        <div className="space-y-4">
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.json"
            onChange={handleFileUpload}
            className="hidden"
            id="file-upload"
          />
          
          <label
            htmlFor="file-upload"
            className={`
              inline-flex items-center justify-center px-6 py-3 border border-transparent rounded-lg text-sm font-medium text-white 
              ${importing ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 cursor-pointer'}
              transition-colors
            `}
          >
            {importing ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Processing...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Choose File
              </>
            )}
          </label>

          <div className="text-sm text-gray-500">
            Supported formats: CSV, JSON • Max file size: 10MB
          </div>
        </div>

        {result && (
          <div className={`mt-6 p-4 rounded-lg ${result.success ? 'bg-green-50' : 'bg-red-50'}`}>
            <div className="flex items-center">
              {result.success ? (
                <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
              )}
              <span className={`text-sm font-medium ${result.success ? 'text-green-800' : 'text-red-800'}`}>
                {result.message}
              </span>
            </div>
            {result.recordsProcessed && (
              <div className="text-sm text-green-700 mt-1">
                {result.recordsProcessed} records processed successfully
              </div>
            )}
            {result.errors && (
              <div className="text-sm text-red-700 mt-2">
                <ul className="list-disc list-inside">
                  {result.errors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        <div className="mt-8 pt-6 border-t border-gray-200">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">Need sample data?</h4>
          <div className="flex justify-center space-x-4">
            <button
              onClick={generateSampleData}
              className="inline-flex items-center px-4 py-2 text-sm text-blue-600 hover:text-blue-800 transition-colors"
            >
              <FileText className="w-4 h-4 mr-1" />
              Download Sample CSV
            </button>
            <a
              href="#"
              className="inline-flex items-center px-4 py-2 text-sm text-blue-600 hover:text-blue-800 transition-colors"
              onClick={(e) => {
                e.preventDefault();
                // Show documentation modal or link
                alert('Documentation: Expected fields include timestamp, stationId, actualDemand, predictedDemand (optional), temperature, weather, events.');
              }}
            >
              <Database className="w-4 h-4 mr-1" />
              View Documentation
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataImport;