import React, { useState, useMemo } from 'react';
import { Search, Download, Filter, TrendingUp, TrendingDown, ArrowUpDown } from 'lucide-react';

interface DemandTableProps {
  timeRange: string;
  station: string;
}

interface DemandRecord {
  id: string;
  station: string;
  timestamp: string;
  actualDemand: number;
  predictedDemand: number;
  accuracy: number;
  status: 'low' | 'medium' | 'high';
  utilization: number;
  peakTime: boolean;
}

const DemandTable: React.FC<DemandTableProps> = ({ timeRange, station }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof DemandRecord>('timestamp');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Generate realistic mock data
  const generateDemandData = (): DemandRecord[] => {
    const stations = [
      'Downtown Hub', 'Mall Complex', 'Highway Rest', 
      'Business District', 'Residential Area', 'Airport Terminal'
    ];
    
    const data: DemandRecord[] = [];
    const now = new Date();
    
    for (let i = 0; i < 100; i++) {
      const timestamp = new Date(now.getTime() - (i * 15 * 60 * 1000)); // 15-minute intervals
      const hour = timestamp.getHours();
      const isPeakTime = (hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19);
      
      const baseDemand = isPeakTime ? 60 + Math.random() * 40 : 20 + Math.random() * 30;
      const actualDemand = Math.round(baseDemand + (Math.random() - 0.5) * 20);
      const predictedDemand = Math.round(actualDemand + (Math.random() - 0.5) * 10);
      const accuracy = Math.round((1 - Math.abs(actualDemand - predictedDemand) / actualDemand) * 100);
      
      let status: 'low' | 'medium' | 'high' = 'low';
      if (actualDemand > 60) status = 'high';
      else if (actualDemand > 35) status = 'medium';
      
      data.push({
        id: `record-${i}`,
        station: stations[Math.floor(Math.random() * stations.length)],
        timestamp: timestamp.toISOString(),
        actualDemand,
        predictedDemand,
        accuracy: Math.max(70, accuracy),
        status,
        utilization: Math.round((actualDemand / 100) * 100),
        peakTime: isPeakTime
      });
    }
    
    return data;
  };

  const data = useMemo(() => generateDemandData(), [timeRange, station]);

  const filteredAndSortedData = useMemo(() => {
    let filtered = data.filter(record => {
      const matchesSearch = record.station.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStation = station === 'all' || record.station === station;
      const matchesStatus = filterStatus === 'all' || record.status === filterStatus;
      
      return matchesSearch && matchesStation && matchesStatus;
    });

    filtered.sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        return sortDirection === 'asc' 
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }
      
      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortDirection === 'asc' ? aValue - bValue : bValue - aValue;
      }
      
      return 0;
    });

    return filtered;
  }, [data, searchTerm, station, filterStatus, sortField, sortDirection]);

  const handleSort = (field: keyof DemandRecord) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const exportData = (format: 'csv' | 'json') => {
    if (format === 'csv') {
      const headers = ['Station', 'Timestamp', 'Actual Demand (kW)', 'Predicted Demand (kW)', 'Accuracy (%)', 'Status', 'Utilization (%)'];
      const csvContent = [
        headers.join(','),
        ...filteredAndSortedData.map(record => [
          record.station,
          new Date(record.timestamp).toLocaleString(),
          record.actualDemand,
          record.predictedDemand,
          record.accuracy,
          record.status,
          record.utilization
        ].join(','))
      ].join('\n');
      
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ev-demand-data-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } else {
      const jsonContent = JSON.stringify(filteredAndSortedData, null, 2);
      const blob = new Blob([jsonContent], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `ev-demand-data-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      window.URL.revokeObjectURL(url);
    }
  };

  const getStatusColor = (status: string) => {
    const colors = {
      low: 'bg-green-100 text-green-800',
      medium: 'bg-yellow-100 text-yellow-800',
      high: 'bg-red-100 text-red-800'
    };
    return colors[status as keyof typeof colors];
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const SortButton: React.FC<{ field: keyof DemandRecord; children: React.ReactNode }> = ({ field, children }) => (
    <button
      onClick={() => handleSort(field)}
      className="flex items-center space-x-1 text-left font-medium text-gray-700 hover:text-gray-900 transition-colors"
    >
      <span>{children}</span>
      {sortField === field ? (
        sortDirection === 'asc' ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />
      ) : (
        <ArrowUpDown className="w-4 h-4 opacity-50" />
      )}
    </button>
  );

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Demand Records</h3>
            <p className="text-sm text-gray-600 mt-1">
              Detailed demand data and prediction accuracy ({filteredAndSortedData.length} records)
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search stations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Status</option>
              <option value="low">Low Demand</option>
              <option value="medium">Medium Demand</option>
              <option value="high">High Demand</option>
            </select>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => exportData('csv')}
                className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
              >
                <Download className="w-4 h-4" />
                <span>CSV</span>
              </button>
              <button
                onClick={() => exportData('json')}
                className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
              >
                <Download className="w-4 h-4" />
                <span>JSON</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <SortButton field="station">Station</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <SortButton field="timestamp">Time</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <SortButton field="actualDemand">Actual (kW)</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <SortButton field="predictedDemand">Predicted (kW)</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <SortButton field="accuracy">Accuracy</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <SortButton field="status">Status</SortButton>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <SortButton field="utilization">Utilization</SortButton>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredAndSortedData.slice(0, 50).map((record) => (
              <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="text-sm font-medium text-gray-900">{record.station}</div>
                    {record.peakTime && (
                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-orange-100 text-orange-800">
                        Peak
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {formatTime(record.timestamp)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                  {record.actualDemand}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {record.predictedDemand}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span className={`font-medium ${record.accuracy >= 90 ? 'text-green-600' : record.accuracy >= 80 ? 'text-yellow-600' : 'text-red-600'}`}>
                    {record.accuracy}%
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(record.status)}`}>
                    {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  <div className="flex items-center">
                    <div className="w-16 bg-gray-200 rounded-full h-2 mr-2">
                      <div 
                        className={`h-2 rounded-full ${record.utilization >= 80 ? 'bg-red-500' : record.utilization >= 60 ? 'bg-yellow-500' : 'bg-green-500'}`}
                        style={{ width: `${Math.min(record.utilization, 100)}%` }}
                      ></div>
                    </div>
                    <span className="text-xs font-medium">{record.utilization}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {filteredAndSortedData.length > 50 && (
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <p className="text-sm text-gray-600">
            Showing first 50 of {filteredAndSortedData.length} records. Use filters to narrow results or export all data.
          </p>
        </div>
      )}
    </div>
  );
};

export default DemandTable;