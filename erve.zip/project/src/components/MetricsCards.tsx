import React from 'react';
import { TrendingUp, TrendingDown, Activity, Zap } from 'lucide-react';

interface MetricsCardsProps {
  timeRange: string;
  showPredictions?: boolean;
}

const MetricsCards: React.FC<MetricsCardsProps> = ({ timeRange, showPredictions = false }) => {
  const metrics = [
    {
      title: 'Total Demand',
      value: '2,847',
      unit: 'kWh',
      change: 12.5,
      trend: 'up',
      icon: Activity,
      color: 'blue'
    },
    {
      title: 'Peak Demand',
      value: '456',
      unit: 'kW',
      change: -2.1,
      trend: 'down',
      icon: TrendingUp,
      color: 'emerald'
    },
    {
      title: 'Active Stations',
      value: '12',
      unit: 'stations',
      change: 0,
      trend: 'stable',
      icon: Zap,
      color: 'orange'
    },
    {
      title: showPredictions ? 'Forecast Accuracy' : 'Avg Utilization',
      value: showPredictions ? '94.2' : '78.5',
      unit: '%',
      change: showPredictions ? 1.2 : 5.3,
      trend: 'up',
      icon: TrendingUp,
      color: 'purple'
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-50 text-blue-600',
      emerald: 'bg-emerald-50 text-emerald-600',
      orange: 'bg-orange-50 text-orange-600',
      purple: 'bg-purple-50 text-purple-600'
    };
    return colors[color as keyof typeof colors];
  };

  const getTrendColor = (trend: string) => {
    if (trend === 'up') return 'text-green-600';
    if (trend === 'down') return 'text-red-600';
    return 'text-gray-600';
  };

  const getTrendIcon = (trend: string) => {
    if (trend === 'up') return <TrendingUp className="w-4 h-4" />;
    if (trend === 'down') return <TrendingDown className="w-4 h-4" />;
    return <Activity className="w-4 h-4" />;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric, index) => (
        <div key={index} className="bg-white rounded-lg shadow-sm p-6 border border-gray-200 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className={`p-2 rounded-lg ${getColorClasses(metric.color)}`}>
              <metric.icon className="w-5 h-5" />
            </div>
            <div className={`flex items-center space-x-1 text-sm ${getTrendColor(metric.trend)}`}>
              {getTrendIcon(metric.trend)}
              <span className="font-medium">
                {metric.change !== 0 ? `${metric.change > 0 ? '+' : ''}${metric.change}%` : '—'}
              </span>
            </div>
          </div>
          
          <div className="space-y-1">
            <h3 className="text-sm font-medium text-gray-600">{metric.title}</h3>
            <div className="flex items-baseline space-x-2">
              <span className="text-2xl font-bold text-gray-900">{metric.value}</span>
              <span className="text-sm text-gray-500">{metric.unit}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MetricsCards;