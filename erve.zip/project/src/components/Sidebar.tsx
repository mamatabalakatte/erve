import React from 'react';
import { Calendar, MapPin, BarChart3, TrendingUp, Settings } from 'lucide-react';

interface SidebarProps {
  selectedTimeRange: string;
  setSelectedTimeRange: (range: string) => void;
  selectedStation: string;
  setSelectedStation: (station: string) => void;
  viewMode: string;
  setViewMode: (mode: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  selectedTimeRange,
  setSelectedTimeRange,
  selectedStation,
  setSelectedStation,
  viewMode,
  setViewMode
}) => {
  const timeRanges = [
    { value: '1h', label: 'Last Hour' },
    { value: '24h', label: 'Last 24 Hours' },
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 90 Days' }
  ];

  const stations = [
    { value: 'all', label: 'All Stations' },
    { value: 'station-1', label: 'Downtown Hub' },
    { value: 'station-2', label: 'Mall Complex' },
    { value: 'station-3', label: 'Highway Rest' },
    { value: 'station-4', label: 'Business District' },
    { value: 'station-5', label: 'Residential Area' }
  ];

  const viewModes = [
    { value: 'overview', label: 'Overview', icon: BarChart3 },
    { value: 'predictions', label: 'Predictions', icon: TrendingUp },
    { value: 'locations', label: 'Locations', icon: MapPin },
    { value: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <aside className="w-80 bg-white shadow-sm border-r border-gray-200 min-h-screen">
      <div className="p-6">
        <div className="space-y-6">
          {/* View Mode Selection */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Dashboard Views</h3>
            <div className="space-y-1">
              {viewModes.map((mode) => (
                <button
                  key={mode.value}
                  onClick={() => setViewMode(mode.value)}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    viewMode === mode.value
                      ? 'bg-blue-50 text-blue-700 border border-blue-200'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <mode.icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{mode.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Time Range Selection */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              Time Range
            </h3>
            <select
              value={selectedTimeRange}
              onChange={(e) => setSelectedTimeRange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              {timeRanges.map((range) => (
                <option key={range.value} value={range.value}>
                  {range.label}
                </option>
              ))}
            </select>
          </div>

          {/* Station Selection */}
          <div>
            <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
              <MapPin className="w-4 h-4 mr-2" />
              Station Filter
            </h3>
            <select
              value={selectedStation}
              onChange={(e) => setSelectedStation(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              {stations.map((station) => (
                <option key={station.value} value={station.value}>
                  {station.label}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Stats */}
          <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Quick Stats</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Active Stations</span>
                <span className="font-medium text-gray-900">12</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Current Demand</span>
                <span className="font-medium text-green-600">High</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Prediction Accuracy</span>
                <span className="font-medium text-blue-600">94.2%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;