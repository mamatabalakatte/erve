import React from 'react';
import { BarChart3 } from 'lucide-react';

interface DemandChartProps {
  timeRange: string;
  station: string;
}

const DemandChart: React.FC<DemandChartProps> = ({ timeRange, station }) => {
  // Mock data - in a real app, this would come from your dataset
  const generateMockData = () => {
    const hours = Array.from({ length: 24 }, (_, i) => i);
    return hours.map(hour => ({
      time: `${hour.toString().padStart(2, '0')}:00`,
      demand: Math.floor(Math.random() * 100) + 20 + (hour >= 7 && hour <= 19 ? 40 : 0),
      predicted: Math.floor(Math.random() * 100) + 25 + (hour >= 7 && hour <= 19 ? 35 : 0)
    }));
  };

  const data = generateMockData();
  const maxValue = Math.max(...data.map(d => Math.max(d.demand, d.predicted)));

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
            Demand vs Predicted
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            {station === 'all' ? 'All Stations' : station} • {timeRange}
          </p>
        </div>
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-gray-600">Actual</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
            <span className="text-gray-600">Predicted</span>
          </div>
        </div>
      </div>

      <div className="h-64 flex items-end space-x-1">
        {data.map((point, index) => (
          <div key={index} className="flex-1 flex flex-col items-center">
            <div className="flex items-end space-x-1 w-full h-48">
              <div 
                className="bg-blue-500 rounded-t-sm transition-all duration-300 hover:bg-blue-600 flex-1"
                style={{ height: `${(point.demand / maxValue) * 100}%` }}
                title={`Actual: ${point.demand} kW`}
              ></div>
              <div 
                className="bg-emerald-500 rounded-t-sm transition-all duration-300 hover:bg-emerald-600 flex-1"
                style={{ height: `${(point.predicted / maxValue) * 100}%` }}
                title={`Predicted: ${point.predicted} kW`}
              ></div>
            </div>
            <span className="text-xs text-gray-500 mt-2 transform -rotate-45 origin-left">
              {point.time}
            </span>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="grid grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="font-semibold text-gray-900">Average</div>
            <div className="text-gray-600">
              {Math.round(data.reduce((sum, d) => sum + d.demand, 0) / data.length)} kW
            </div>
          </div>
          <div className="text-center">
            <div className="font-semibold text-gray-900">Peak</div>
            <div className="text-gray-600">
              {Math.max(...data.map(d => d.demand))} kW
            </div>
          </div>
          <div className="text-center">
            <div className="font-semibold text-gray-900">Accuracy</div>
            <div className="text-green-600 font-medium">94.2%</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DemandChart;