import React from 'react';
import { TrendingUp } from 'lucide-react';

interface PredictionChartProps {
  timeRange: string;
  station: string;
  detailed?: boolean;
}

const PredictionChart: React.FC<PredictionChartProps> = ({ timeRange, station, detailed = false }) => {
  const generateForecastData = () => {
    const points = detailed ? 48 : 24;
    return Array.from({ length: points }, (_, i) => {
      const baseValue = 50 + Math.sin(i * 0.3) * 30;
      const noise = (Math.random() - 0.5) * 10;
      return {
        time: detailed ? `${Math.floor(i/2).toString().padStart(2, '0')}:${i % 2 === 0 ? '00' : '30'}` : `${i.toString().padStart(2, '0')}:00`,
        value: Math.max(10, baseValue + noise),
        confidence: 85 + Math.random() * 10
      };
    });
  };

  const data = generateForecastData();
  const maxValue = Math.max(...data.map(d => d.value));

  return (
    <div className={`bg-white rounded-lg shadow-sm p-6 border border-gray-200 ${detailed ? 'lg:col-span-2' : ''}`}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-emerald-600" />
            {detailed ? 'Detailed Demand Forecast' : 'Next 24H Forecast'}
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            ML-powered predictions • Confidence: 94.2%
          </p>
        </div>
        <div className="text-right">
          <div className="text-sm text-gray-500">Next Peak</div>
          <div className="text-lg font-semibold text-emerald-600">
            {Math.round(Math.max(...data.map(d => d.value)))} kW
          </div>
        </div>
      </div>

      <div className="h-64 relative">
        <svg className="w-full h-full" viewBox="0 0 800 200">
          <defs>
            <linearGradient id="forecastGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="rgb(16, 185, 129)" stopOpacity="0.3" />
              <stop offset="100%" stopColor="rgb(16, 185, 129)" stopOpacity="0.1" />
            </linearGradient>
          </defs>
          
          {/* Grid lines */}
          {[0, 25, 50, 75, 100].map((y) => (
            <line
              key={y}
              x1="0"
              y1={200 - (y * 2)}
              x2="800"
              y2={200 - (y * 2)}
              stroke="#f3f4f6"
              strokeWidth="1"
            />
          ))}

          {/* Forecast line */}
          <path
            d={`M ${data.map((point, index) => 
              `${(index / (data.length - 1)) * 800},${200 - (point.value / maxValue) * 180}`
            ).join(' L ')}`}
            fill="none"
            stroke="rgb(16, 185, 129)"
            strokeWidth="3"
            className="drop-shadow-sm"
          />

          {/* Confidence area */}
          <path
            d={`M ${data.map((point, index) => 
              `${(index / (data.length - 1)) * 800},${200 - (point.value / maxValue) * 180}`
            ).join(' L ')} L 800,200 L 0,200 Z`}
            fill="url(#forecastGradient)"
          />

          {/* Data points */}
          {data.map((point, index) => (
            <circle
              key={index}
              cx={(index / (data.length - 1)) * 800}
              cy={200 - (point.value / maxValue) * 180}
              r="4"
              fill="rgb(16, 185, 129)"
              className="hover:r-6 transition-all cursor-pointer"
            >
              <title>
                {point.time}: {Math.round(point.value)} kW (Confidence: {Math.round(point.confidence)}%)
              </title>
            </circle>
          ))}
        </svg>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="grid grid-cols-4 gap-4 text-sm">
          <div className="text-center">
            <div className="font-semibold text-gray-900">Avg Forecast</div>
            <div className="text-emerald-600">
              {Math.round(data.reduce((sum, d) => sum + d.value, 0) / data.length)} kW
            </div>
          </div>
          <div className="text-center">
            <div className="font-semibold text-gray-900">Peak Time</div>
            <div className="text-gray-600">
              {data[data.findIndex(d => d.value === Math.max(...data.map(p => p.value)))].time}
            </div>
          </div>
          <div className="text-center">
            <div className="font-semibold text-gray-900">Model</div>
            <div className="text-gray-600">LSTM + XGBoost</div>
          </div>
          <div className="text-center">
            <div className="font-semibold text-gray-900">Last Updated</div>
            <div className="text-gray-600">2 min ago</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PredictionChart;