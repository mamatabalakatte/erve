import React from 'react';
import { MapPin, Zap, Users } from 'lucide-react';

interface StationMapProps {
  selectedStation: string;
}

const StationMap: React.FC<StationMapProps> = ({ selectedStation }) => {
  const stations = [
    { id: 'station-1', name: 'Downtown Hub', x: 25, y: 40, status: 'high', utilization: 89 },
    { id: 'station-2', name: 'Mall Complex', x: 60, y: 25, status: 'medium', utilization: 67 },
    { id: 'station-3', name: 'Highway Rest', x: 80, y: 60, status: 'low', utilization: 34 },
    { id: 'station-4', name: 'Business District', x: 40, y: 70, status: 'high', utilization: 92 },
    { id: 'station-5', name: 'Residential Area', x: 15, y: 80, status: 'medium', utilization: 56 }
  ];

  const getStatusColor = (status: string) => {
    const colors = {
      high: 'bg-red-500 border-red-600 shadow-red-500/50',
      medium: 'bg-yellow-500 border-yellow-600 shadow-yellow-500/50',
      low: 'bg-green-500 border-green-600 shadow-green-500/50'
    };
    return colors[status as keyof typeof colors];
  };

  const getStatusText = (status: string) => {
    const texts = {
      high: 'High Demand',
      medium: 'Medium Demand',
      low: 'Low Demand'
    };
    return texts[status as keyof typeof texts];
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 flex items-center">
            <MapPin className="w-5 h-5 mr-2 text-blue-600" />
            Station Locations & Demand
          </h3>
          <p className="text-sm text-gray-600 mt-1">Real-time station utilization map</p>
        </div>
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-gray-600">Low</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
            <span className="text-gray-600">Medium</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-gray-600">High</span>
          </div>
        </div>
      </div>

      <div className="relative h-80 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg border border-gray-200 overflow-hidden">
        {/* Mock map background */}
        <div className="absolute inset-0 opacity-10">
          <div className="w-full h-full bg-gray-400 relative">
            {/* Mock city blocks */}
            <div className="absolute top-10 left-10 w-20 h-8 bg-gray-600 rounded-sm"></div>
            <div className="absolute top-20 left-40 w-16 h-12 bg-gray-600 rounded-sm"></div>
            <div className="absolute bottom-20 right-20 w-24 h-10 bg-gray-600 rounded-sm"></div>
            <div className="absolute bottom-10 left-20 w-18 h-14 bg-gray-600 rounded-sm"></div>
          </div>
        </div>

        {/* Station markers */}
        {stations.map((station) => (
          <div
            key={station.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
            style={{ left: `${station.x}%`, top: `${station.y}%` }}
          >
            <div className={`
              w-6 h-6 rounded-full border-2 shadow-lg transition-all duration-200 
              ${getStatusColor(station.status)}
              ${selectedStation === station.id ? 'scale-150 z-10' : 'group-hover:scale-125'}
            `}>
              <Zap className="w-3 h-3 text-white m-auto mt-0.5" />
            </div>
            
            {/* Tooltip */}
            <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded-lg py-2 px-3 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-20">
              <div className="font-medium">{station.name}</div>
              <div className="text-gray-300">{getStatusText(station.status)}</div>
              <div className="text-gray-300">Utilization: {station.utilization}%</div>
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black"></div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="text-center p-4 bg-red-50 rounded-lg">
          <div className="flex items-center justify-center mb-2">
            <Users className="w-5 h-5 text-red-600 mr-2" />
            <span className="font-semibold text-red-900">High Demand</span>
          </div>
          <div className="text-2xl font-bold text-red-600">2</div>
          <div className="text-sm text-red-700">stations</div>
        </div>
        
        <div className="text-center p-4 bg-yellow-50 rounded-lg">
          <div className="flex items-center justify-center mb-2">
            <Users className="w-5 h-5 text-yellow-600 mr-2" />
            <span className="font-semibold text-yellow-900">Medium Demand</span>
          </div>
          <div className="text-2xl font-bold text-yellow-600">2</div>
          <div className="text-sm text-yellow-700">stations</div>
        </div>
        
        <div className="text-center p-4 bg-green-50 rounded-lg">
          <div className="flex items-center justify-center mb-2">
            <Users className="w-5 h-5 text-green-600 mr-2" />
            <span className="font-semibold text-green-900">Low Demand</span>
          </div>
          <div className="text-2xl font-bold text-green-600">1</div>
          <div className="text-sm text-green-700">station</div>
        </div>
      </div>
    </div>
  );
};

export default StationMap;