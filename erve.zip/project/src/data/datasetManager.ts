export interface StationData {
  id: string;
  name: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  capacity: number;
  connectorTypes: string[];
  pricing: {
    rate: number;
    currency: string;
  };
}

export interface DemandPoint {
  timestamp: Date;
  stationId: string;
  actualDemand: number;
  predictedDemand?: number;
  weather: {
    temperature: number;
    condition: string;
    windSpeed: number;
  };
  events: string[];
  dayOfWeek: number;
  isHoliday: boolean;
}

export interface PredictionModel {
  name: string;
  type: 'LSTM' | 'XGBoost' | 'RandomForest' | 'Linear';
  accuracy: number;
  lastTrained: Date;
  features: string[];
}

export class DatasetManager {
  private stations: StationData[] = [];
  private historicalData: DemandPoint[] = [];
  private models: PredictionModel[] = [];

  constructor() {
    this.initializeDataset();
  }

  private initializeDataset() {
    // Initialize stations
    this.stations = [
      {
        id: 'station-1',
        name: 'Downtown Hub',
        location: { lat: 40.7589, lng: -73.9851, address: '123 Broadway, New York, NY' },
        capacity: 100,
        connectorTypes: ['CHAdeMO', 'CCS', 'Tesla'],
        pricing: { rate: 0.35, currency: 'USD' }
      },
      {
        id: 'station-2',
        name: 'Mall Complex',
        location: { lat: 40.7505, lng: -73.9934, address: '456 5th Ave, New York, NY' },
        capacity: 75,
        connectorTypes: ['CCS', 'Tesla'],
        pricing: { rate: 0.32, currency: 'USD' }
      },
      {
        id: 'station-3',
        name: 'Highway Rest',
        location: { lat: 40.7282, lng: -74.0776, address: '789 Highway 95, New York, NY' },
        capacity: 150,
        connectorTypes: ['CHAdeMO', 'CCS', 'Tesla', 'Type 2'],
        pricing: { rate: 0.38, currency: 'USD' }
      },
      {
        id: 'station-4',
        name: 'Business District',
        location: { lat: 40.7614, lng: -73.9776, address: '321 Wall St, New York, NY' },
        capacity: 80,
        connectorTypes: ['CCS', 'Tesla'],
        pricing: { rate: 0.36, currency: 'USD' }
      },
      {
        id: 'station-5',
        name: 'Residential Area',
        location: { lat: 40.7831, lng: -73.9712, address: '654 Central Park W, New York, NY' },
        capacity: 50,
        connectorTypes: ['CCS', 'Type 2'],
        pricing: { rate: 0.30, currency: 'USD' }
      }
    ];

    // Initialize prediction models
    this.models = [
      {
        name: 'Primary LSTM',
        type: 'LSTM',
        accuracy: 94.2,
        lastTrained: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        features: ['time_of_day', 'day_of_week', 'weather', 'historical_usage', 'events']
      },
      {
        name: 'XGBoost Ensemble',
        type: 'XGBoost',
        accuracy: 91.8,
        lastTrained: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        features: ['weather', 'day_of_week', 'local_events', 'pricing', 'capacity']
      }
    ];

    this.generateHistoricalData();
  }

  private generateHistoricalData() {
    const now = new Date();
    const daysBack = 90;
    
    for (let d = 0; d < daysBack; d++) {
      const date = new Date(now.getTime() - d * 24 * 60 * 60 * 1000);
      
      // Generate 24 hours of data for each day
      for (let h = 0; h < 24; h++) {
        const timestamp = new Date(date);
        timestamp.setHours(h, 0, 0, 0);
        
        this.stations.forEach(station => {
          const baseUsage = this.calculateBaseUsage(h, date.getDay(), station);
          const weatherFactor = this.generateWeatherFactor();
          const eventFactor = this.generateEventFactor(date);
          
          const actualDemand = Math.max(0, Math.round(
            baseUsage * weatherFactor * eventFactor + (Math.random() - 0.5) * 10
          ));
          
          this.historicalData.push({
            timestamp,
            stationId: station.id,
            actualDemand,
            weather: {
              temperature: 15 + Math.random() * 20,
              condition: ['sunny', 'cloudy', 'rainy'][Math.floor(Math.random() * 3)],
              windSpeed: Math.random() * 15
            },
            events: this.generateEvents(date),
            dayOfWeek: date.getDay(),
            isHoliday: this.isHoliday(date)
          });
        });
      }
    }
  }

  private calculateBaseUsage(hour: number, dayOfWeek: number, station: StationData): number {
    let baseUsage = station.capacity * 0.3; // 30% base utilization
    
    // Time of day patterns
    if (hour >= 7 && hour <= 9) baseUsage *= 1.8; // Morning rush
    else if (hour >= 17 && hour <= 19) baseUsage *= 2.0; // Evening rush
    else if (hour >= 11 && hour <= 13) baseUsage *= 1.3; // Lunch time
    else if (hour >= 22 || hour <= 5) baseUsage *= 0.3; // Night time
    
    // Day of week patterns
    if (dayOfWeek === 0 || dayOfWeek === 6) baseUsage *= 0.7; // Weekends
    else if (dayOfWeek === 1) baseUsage *= 1.1; // Monday boost
    
    // Station-specific patterns
    if (station.name.includes('Business')) {
      if (dayOfWeek >= 1 && dayOfWeek <= 5 && hour >= 8 && hour <= 18) {
        baseUsage *= 1.4;
      }
    } else if (station.name.includes('Mall')) {
      if ((dayOfWeek === 0 || dayOfWeek === 6) && hour >= 10 && hour <= 20) {
        baseUsage *= 1.6;
      }
    }
    
    return baseUsage;
  }

  private generateWeatherFactor(): number {
    return 0.8 + Math.random() * 0.4; // Weather can affect usage by ±20%
  }

  private generateEventFactor(date: Date): number {
    // Simulate special events
    if (Math.random() < 0.1) return 1.5; // 10% chance of event boosting demand
    if (Math.random() < 0.05) return 0.6; // 5% chance of event reducing demand
    return 1.0;
  }

  private generateEvents(date: Date): string[] {
    const events = [];
    if (Math.random() < 0.1) events.push('Local Event');
    if (Math.random() < 0.05) events.push('Concert');
    if (Math.random() < 0.03) events.push('Sports Game');
    return events;
  }

  private isHoliday(date: Date): boolean {
    // Simplified holiday detection
    const month = date.getMonth();
    const day = date.getDate();
    
    // Major US holidays
    return (
      (month === 0 && day === 1) || // New Year
      (month === 6 && day === 4) || // Independence Day
      (month === 11 && day === 25)  // Christmas
    );
  }

  // Public methods
  getStations(): StationData[] {
    return [...this.stations];
  }

  getHistoricalData(stationId?: string, startDate?: Date, endDate?: Date): DemandPoint[] {
    let filtered = [...this.historicalData];
    
    if (stationId && stationId !== 'all') {
      filtered = filtered.filter(point => point.stationId === stationId);
    }
    
    if (startDate) {
      filtered = filtered.filter(point => point.timestamp >= startDate);
    }
    
    if (endDate) {
      filtered = filtered.filter(point => point.timestamp <= endDate);
    }
    
    return filtered.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  getPredictionModels(): PredictionModel[] {
    return [...this.models];
  }

  generatePredictions(stationId: string, hoursAhead: number): DemandPoint[] {
    const station = this.stations.find(s => s.id === stationId);
    if (!station) return [];
    
    const predictions: DemandPoint[] = [];
    const now = new Date();
    
    for (let h = 1; h <= hoursAhead; h++) {
      const timestamp = new Date(now.getTime() + h * 60 * 60 * 1000);
      const baseUsage = this.calculateBaseUsage(
        timestamp.getHours(),
        timestamp.getDay(),
        station
      );
      
      // Add some prediction uncertainty
      const predictedDemand = Math.max(0, Math.round(
        baseUsage + (Math.random() - 0.5) * baseUsage * 0.2
      ));
      
      predictions.push({
        timestamp,
        stationId,
        actualDemand: 0, // Unknown future value
        predictedDemand,
        weather: {
          temperature: 18 + Math.random() * 10,
          condition: 'predicted',
          windSpeed: Math.random() * 10
        },
        events: [],
        dayOfWeek: timestamp.getDay(),
        isHoliday: this.isHoliday(timestamp)
      });
    }
    
    return predictions;
  }

  exportData(format: 'csv' | 'json', stationId?: string): string {
    const data = this.getHistoricalData(stationId);
    
    if (format === 'csv') {
      const headers = [
        'Timestamp', 'Station ID', 'Station Name', 'Actual Demand', 
        'Temperature', 'Weather', 'Day of Week', 'Is Holiday', 'Events'
      ];
      
      const rows = data.map(point => {
        const station = this.stations.find(s => s.id === point.stationId);
        return [
          point.timestamp.toISOString(),
          point.stationId,
          station?.name || '',
          point.actualDemand,
          point.weather.temperature,
          point.weather.condition,
          point.dayOfWeek,
          point.isHoliday,
          point.events.join(';')
        ];
      });
      
      return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    } else {
      return JSON.stringify({
        stations: this.stations,
        data: data,
        models: this.models,
        exportTimestamp: new Date().toISOString()
      }, null, 2);
    }
  }

  calculateAccuracy(actual: number[], predicted: number[]): number {
    if (actual.length !== predicted.length || actual.length === 0) return 0;
    
    const mape = actual.reduce((sum, actualVal, i) => {
      const error = Math.abs(actualVal - predicted[i]) / Math.max(actualVal, 1);
      return sum + error;
    }, 0) / actual.length;
    
    return Math.max(0, (1 - mape) * 100);
  }
}

// Singleton instance
export const datasetManager = new DatasetManager();